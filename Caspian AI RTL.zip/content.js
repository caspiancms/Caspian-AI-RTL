(async function () {
  const host = location.hostname;

  function builtInSiteKey() {
    if (host.includes("claude.ai")) return "claude";
    if (host.includes("chatgpt.com") || host.includes("chat.openai.com")) return "chatgpt";
    if (host.includes("gemini.google.com")) return "gemini";
    if (host.includes("grok.com") || host.includes("x.ai")) return "grok";
    if (host.includes("poe.com")) return "poe";
    if (host.includes("copilot.microsoft.com") || host.includes("bing.com")) return "copilot";
    if (host.includes("perplexity.ai")) return "perplexity";
    if (host.includes("huggingface.co")) return "huggingchat";
    if (host.includes("character.ai")) return "characterai";
    if (host.includes("deepseek.com")) return "deepseek";
    if (host.includes("mistral.ai")) return "lechat";
    if (host.includes("you.com")) return "you";
    if (host.includes("kagi.com")) return "kagi";
    if (host.includes("qwen.ai")) return "qwen";
    if (host.includes("z.ai")) return "zai";
    return null;
  }

  // ابتدا سایت‌های دلخواهی که خود کاربر اضافه کرده را بررسی می‌کنیم
  // (بر اساس دامنه ذخیره‌شده در storage)، سپس سایت‌های از‌پیش‌تعریف‌شده
  async function resolveSiteKey() {
    const built = builtInSiteKey();
    if (built) return built;
    try {
      const data = await chrome.storage.local.get(["customSites"]);
      const customSites = data.customSites || [];
      const match = customSites.find((s) => host === s.host || host.endsWith("." + s.host));
      if (match) return match.key;
    } catch (e) {
      /* در صورت خطا به کلید عمومی برمی‌گردیم */
    }
    return "other";
  }

  const SITE = await resolveSiteKey();

  // ---------- راست‌چین کردن ----------
  function applyRtlSetting() {
    chrome.storage.local.get(["rtlEnabled", "rtlSites"], (data) => {
      const globalEnabled = data.rtlEnabled !== false; // پیش‌فرض روشن
      const perSite = data.rtlSites || {};
      const enabledForSite = perSite[SITE] !== false; // پیش‌فرض روشن مگر کاربر خاموش کرده باشد
      const html = document.documentElement;
      if (globalEnabled && enabledForSite) {
        html.classList.add("ai-rtl-forced");
      } else {
        html.classList.remove("ai-rtl-forced");
      }
    });
  }

  applyRtlSetting();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.rtlEnabled || changes.rtlSites)) {
      applyRtlSetting();
    }
  });

  // برخی سایت‌ها (React/SPA) محتوا را دوباره رندر می‌کنند؛ کلاس را حفظ می‌کنیم
  const rtlObserver = new MutationObserver(() => applyRtlSetting());
  rtlObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });

  // ---------- ایزوله کردن بلوک‌های کد از راست‌چین شدن ----------
  // فقط CSS کافی نیست: الگوریتم bidi مرورگر برای مرتب‌سازی بصری خط‌ها از
  // ویژگی HTML به‌نام dir استفاده می‌کند، نه فقط استایل direction. اگر این
  // ویژگی روی خودِ بلوک کد ست نشود، ترتیب کوتیشن‌ها/علائم داخل کد به‌هم
  // می‌ریزد حتی وقتی رنگ و فونت درست به نظر می‌رسد. پس علاوه بر rtl.css،
  // این ویژگی را مستقیماً روی عنصر ست می‌کنیم.
  const CODE_SELECTOR =
    'pre, code, kbd, samp, [class*="code-block"], [class*="language-"], ' +
    '[class*="hljs"], [class*="token"], [class^="cm-"], [class*=" cm-"], ' +
    '[class*="monaco-editor"], [class*="shiki"]';

  function forceLtrOnCodeBlocks(root) {
    if (!root || !root.querySelectorAll) return;
    const nodes = root.matches && root.matches(CODE_SELECTOR) ? [root] : [];
    nodes.push(...root.querySelectorAll(CODE_SELECTOR));
    for (const el of nodes) {
      if (el.getAttribute("dir") !== "ltr") {
        el.setAttribute("dir", "ltr");
      }
    }
  }

  forceLtrOnCodeBlocks(document.body);

  const codeObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType === 1) forceLtrOnCodeBlocks(node);
      }
    }
  });
  if (document.body) {
    codeObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ---------- تخمین مصرف توکن ----------
  // چون هیچ‌کدام از این پلتفرم‌ها شمارش دقیق توکن را در صفحه نشان نمی‌دهند،
  // این بخش یک برآورد تقریبی بر اساس تعداد کاراکترهای متن رد و بدل شده در صفحه ارائه می‌دهد
  // (تخمین متداول: هر ۴ کاراکتر ≈ ۱ توکن برای متن انگلیسی، برای فارسی کمی متفاوت است).

  let lastTextLength = document.body ? document.body.innerText.length : 0;

  function estimateTokensFromChars(chars) {
    return Math.max(0, Math.round(chars / 4));
  }

  function recordUsage(deltaChars) {
    if (deltaChars <= 0) return;
    const tokens = estimateTokensFromChars(deltaChars);
    if (tokens <= 0) return;
    chrome.runtime.sendMessage({
      type: "AI_USAGE_UPDATE",
      site: SITE,
      tokens: tokens,
    });
  }

  function checkTextGrowth() {
    if (!document.body) return;
    const currentLength = document.body.innerText.length;
    const delta = currentLength - lastTextLength;
    // فقط رشد را حساب می‌کنیم تا حذف/ویرایش متن باعث عدد منفی نشود
    if (delta > 0 && delta < 200000) {
      recordUsage(delta);
    }
    lastTextLength = currentLength;
  }

  // هر ۴ ثانیه رشد متن صفحه را بررسی می‌کنیم (سبک و بدون فشار به CPU)
  setInterval(checkTextGrowth, 4000);

  // وقتی کاربر تب را ترک می‌کند هم یک بار آخر بررسی می‌شود
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      checkTextGrowth();
    }
  });

  // ---------- خواندن سهمیه‌ی واقعی مصرف از خود سایت ----------
  // بعضی سایت‌ها (مثل کلود) خودشان یک نوار پیشرفت دقیق نشان می‌دهند، به این شکل:
  // "Session: 22.8% · resets in 4h 43m" و "Weekly: 78.5% · resets in 1d 21h"
  // این عدد واقعی و دقیق است (نه تخمین ما)، پس به‌جای حدس زدن، همین متن را از
  // صفحه استخراج می‌کنیم و مستقیماً در پاپ‌آپ نشان می‌دهیم.
  const QUOTA_REGEX = /([A-Za-z\u0600-\u06FF ]{2,20}):\s*(\d{1,3}(?:\.\d+)?)%\s*[·•\-]?\s*resets?\s+in\s+([0-9dhms\s]{2,15})/gi;

  function scanForOfficialQuota() {
    if (!document.body) return;
    const text = document.body.innerText;
    const matches = [];
    let m;
    QUOTA_REGEX.lastIndex = 0;
    while ((m = QUOTA_REGEX.exec(text)) !== null && matches.length < 6) {
      matches.push({
        label: m[1].trim(),
        percent: parseFloat(m[2]),
        resetsIn: m[3].trim(),
      });
    }
    if (matches.length > 0) {
      chrome.runtime.sendMessage({
        type: "OFFICIAL_QUOTA_UPDATE",
        site: SITE,
        quotas: matches,
      });
    }
  }

  setInterval(scanForOfficialQuota, 5000);
  scanForOfficialQuota();
})();
