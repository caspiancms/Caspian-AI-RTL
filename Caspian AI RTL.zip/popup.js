let CURRENT_LANG = "fa";

function t(key) {
  return I18N[CURRENT_LANG][key];
}

function applyStaticTranslations() {
  const dict = I18N[CURRENT_LANG];

  document.documentElement.lang = CURRENT_LANG;
  document.documentElement.dir = dict.dir;

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    if (typeof dict[key] === "string") {
      if (el.tagName === "TITLE") {
        el.textContent = dict[key];
        document.title = dict[key];
      } else {
        el.textContent = dict[key];
      }
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    if (typeof dict[key] === "string") {
      el.placeholder = dict[key];
    }
  });
}

function todayKey(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() - offsetDays);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function fmt(n) {
  return n.toLocaleString(CURRENT_LANG === "fa" ? "fa-IR" : "en-US");
}

function getLabelMap(customSites) {
  const map = { ...I18N[CURRENT_LANG].siteLabels };
  for (const s of customSites || []) {
    map[s.key] = s.label;
  }
  return map;
}

function renderUsageList(container, totalEl, dataObj, labelMap) {
  const entries = Object.entries(dataObj).sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((s, [, v]) => s + v, 0);
  totalEl.textContent = `${t("totalPrefix")} ${fmt(total)} ${t("tokensSuffix")}`;
  container.replaceChildren();
  if (entries.length === 0) {
    const empty = document.createElement("div");
    empty.className = "usage-item";
    const span = document.createElement("span");
    span.textContent = t("noUsageYet");
    empty.appendChild(span);
    container.appendChild(empty);
    return;
  }
  for (const [site, tokens] of entries) {
    const div = document.createElement("div");
    div.className = "usage-item";

    const nameSpan = document.createElement("span");
    nameSpan.textContent = labelMap[site] || site;

    const tokensSpan = document.createElement("span");
    tokensSpan.className = "u-tokens";
    tokensSpan.textContent = fmt(tokens);

    div.appendChild(nameSpan);
    div.appendChild(tokensSpan);
    container.appendChild(div);
  }
}

function loadUsage() {
  chrome.storage.local.get(["usage", "customSites"], (data) => {
    const usage = data.usage || {};
    const labelMap = getLabelMap(data.customSites);

    const daily = usage[todayKey(0)] || {};
    renderUsageList(document.getElementById("dailyList"), document.getElementById("dailyTotal"), daily, labelMap);

    const weekly = {};
    for (let i = 0; i < 7; i++) {
      const dayData = usage[todayKey(i)] || {};
      for (const [site, tokens] of Object.entries(dayData)) {
        weekly[site] = (weekly[site] || 0) + tokens;
      }
    }
    renderUsageList(document.getElementById("weeklyList"), document.getElementById("weeklyTotal"), weekly, labelMap);
  });
}

function buildSwitchEl(dataKey, enabled) {
  const label = document.createElement("label");
  label.className = "switch";

  const input = document.createElement("input");
  input.type = "checkbox";
  input.dataset.site = dataKey;
  input.checked = enabled;

  const slider = document.createElement("span");
  slider.className = "slider";

  label.appendChild(input);
  label.appendChild(slider);
  return label;
}

function loadSettings() {
  chrome.storage.local.get(["rtlEnabled", "rtlSites", "customSites"], (data) => {
    const globalEnabled = data.rtlEnabled !== false;
    document.getElementById("globalToggle").checked = globalEnabled;

    const perSite = data.rtlSites || {};
    const customSites = data.customSites || [];
    const labelMap = I18N[CURRENT_LANG].siteLabels;
    const sitesList = document.getElementById("sitesList");
    sitesList.replaceChildren();

    for (const [key, label] of Object.entries(labelMap)) {
      const enabled = perSite[key] !== false;
      const div = document.createElement("div");
      div.className = "site-item";

      const nameSpan = document.createElement("span");
      nameSpan.textContent = label;

      div.appendChild(nameSpan);
      div.appendChild(buildSwitchEl(key, enabled));
      sitesList.appendChild(div);
    }

    for (const site of customSites) {
      const enabled = perSite[site.key] !== false;
      const div = document.createElement("div");
      div.className = "site-item custom-site";

      const nameSpan = document.createElement("span");
      nameSpan.textContent = site.label + " ";
      const small = document.createElement("small");
      small.style.color = "#6a6a80";
      small.textContent = `(${site.host})`;
      nameSpan.appendChild(small);

      const rightWrap = document.createElement("span");
      rightWrap.style.display = "flex";
      rightWrap.style.alignItems = "center";
      rightWrap.style.gap = "4px";

      const removeBtn = document.createElement("button");
      removeBtn.className = "remove-site-btn";
      removeBtn.title = t("removeSiteTitle");
      removeBtn.textContent = "✕";
      removeBtn.dataset.removeKey = site.key;

      rightWrap.appendChild(removeBtn);
      rightWrap.appendChild(buildSwitchEl(site.key, enabled));

      div.appendChild(nameSpan);
      div.appendChild(rightWrap);
      sitesList.appendChild(div);
    }

    sitesList.querySelectorAll("input[data-site]").forEach((input) => {
      input.addEventListener("change", (e) => {
        chrome.storage.local.get(["rtlSites"], (d) => {
          const sites = d.rtlSites || {};
          sites[e.target.dataset.site] = e.target.checked;
          chrome.storage.local.set({ rtlSites: sites });
        });
      });
    });

    sitesList.querySelectorAll("button[data-remove-key]").forEach((btn) => {
      btn.addEventListener("click", () => removeCustomSite(btn.dataset.removeKey));
    });
  });
}

function slugify(text) {
  return (
    "custom_" +
    text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "")
      .slice(0, 20) +
    "_" +
    Date.now().toString(36).slice(-4)
  );
}

function extractHost(rawUrl) {
  let value = rawUrl.trim();
  if (!value) return null;
  if (!/^https?:\/\//i.test(value)) {
    value = "https://" + value;
  }
  try {
    const u = new URL(value);
    return u.hostname;
  } catch (e) {
    return null;
  }
}

function showAddMsg(text, isError) {
  const el = document.getElementById("addSiteMsg");
  el.textContent = text;
  el.className = "add-site-msg " + (isError ? "err" : "ok");
}

async function addCustomSite() {
  const nameInput = document.getElementById("newSiteName");
  const urlInput = document.getElementById("newSiteUrl");
  const btn = document.getElementById("addSiteBtn");

  const label = nameInput.value.trim();
  const host = extractHost(urlInput.value);

  if (!label) return showAddMsg(t("msgNeedName"), true);
  if (!host) return showAddMsg(t("msgInvalidUrl"), true);

  const originPattern = `*://${host}/*`;
  const originPatternWildcard = `*://*.${host}/*`;

  // مهم: permissions.request باید مستقیماً و بدون هیچ await قبلی، در همان
  // فراخوانیِ رویداد کلیک صدا زده شود، وگرنه فایرفاکس آن را رد می‌کند.
  let granted;
  try {
    granted = await chrome.permissions.request({
      origins: [originPattern, originPatternWildcard],
    });
  } catch (e) {
    showAddMsg(`${t("msgUnexpected")} ${e.message}`, true);
    return;
  }

  if (!granted) {
    showAddMsg(t("msgPermissionDenied"), true);
    return;
  }

  btn.disabled = true;
  showAddMsg(t("msgRequestingAccess"), false);

  try {
    const data = await chrome.storage.local.get(["customSites"]);
    const customSites = data.customSites || [];
    if (customSites.some((s) => s.host === host)) {
      showAddMsg(t("msgAlreadyAdded"), true);
      btn.disabled = false;
      return;
    }

    const key = slugify(label);
    const site = { key, label, host };

    const res = await chrome.runtime.sendMessage({ type: "REGISTER_CUSTOM_SITE", site });
    if (!res || !res.ok) {
      showAddMsg(t("msgScriptError"), true);
      btn.disabled = false;
      return;
    }

    customSites.push(site);
    await chrome.storage.local.set({ customSites });

    nameInput.value = "";
    urlInput.value = "";
    showAddMsg(t("msgAdded")(label), false);
    loadSettings();
  } catch (e) {
    showAddMsg(`${t("msgUnexpected")} ${e.message}`, true);
  }
  btn.disabled = false;
}

async function removeCustomSite(key) {
  const data = await chrome.storage.local.get(["customSites", "rtlSites"]);
  const customSites = (data.customSites || []).filter((s) => s.key !== key);
  const rtlSites = data.rtlSites || {};
  delete rtlSites[key];

  await chrome.runtime.sendMessage({ type: "UNREGISTER_CUSTOM_SITE", key });
  await chrome.storage.local.set({ customSites, rtlSites });
  loadSettings();
}

function timeAgoLabel(ts) {
  const diffMin = Math.round((Date.now() - ts) / 60000);
  if (diffMin < 1) return CURRENT_LANG === "fa" ? "همین الان" : "just now";
  if (CURRENT_LANG === "fa") return `${diffMin} دقیقه پیش`;
  return `${diffMin} min ago`;
}

function loadOfficialQuota() {
  chrome.storage.local.get(["officialQuota", "customSites"], (data) => {
    const officialQuota = data.officialQuota || {};
    const labelMap = getLabelMap(data.customSites);
    const container = document.getElementById("quotaList");
    container.replaceChildren();

    const siteKeys = Object.keys(officialQuota);
    if (siteKeys.length === 0) {
      const empty = document.createElement("div");
      empty.className = "quota-empty";
      empty.textContent = t("quotaEmpty");
      container.appendChild(empty);
      return;
    }

    for (const site of siteKeys) {
      const entry = officialQuota[site];
      if (!entry || !entry.quotas || entry.quotas.length === 0) continue;

      const block = document.createElement("div");
      block.className = "quota-site-block";

      const nameEl = document.createElement("div");
      nameEl.className = "quota-site-name";
      nameEl.textContent = labelMap[site] || site;
      block.appendChild(nameEl);

      for (const q of entry.quotas) {
        const row = document.createElement("div");
        row.className = "quota-row";

        const labelSpan = document.createElement("span");
        labelSpan.className = "quota-label";
        labelSpan.textContent = q.label;

        const track = document.createElement("div");
        track.className = "quota-bar-track";
        const fill = document.createElement("div");
        fill.className = "quota-bar-fill" + (q.percent >= 85 ? " high" : "");
        fill.style.width = Math.min(100, Math.max(0, q.percent)) + "%";
        track.appendChild(fill);

        const percentSpan = document.createElement("span");
        percentSpan.className = "quota-percent";
        percentSpan.textContent = q.percent + "%";

        const resetsSpan = document.createElement("span");
        resetsSpan.className = "quota-resets";
        resetsSpan.textContent = `${t("quotaResetsPrefix")} ${q.resetsIn}`;

        row.appendChild(labelSpan);
        row.appendChild(track);
        row.appendChild(percentSpan);
        row.appendChild(resetsSpan);
        block.appendChild(row);
      }

      const detectedEl = document.createElement("div");
      detectedEl.className = "quota-resets";
      detectedEl.style.marginTop = "4px";
      detectedEl.textContent = `${t("quotaDetectedPrefix")} ${timeAgoLabel(entry.detectedAt)}`;
      block.appendChild(detectedEl);

      container.appendChild(block);
    }

    if (container.children.length === 0) {
      const empty = document.createElement("div");
      empty.className = "quota-empty";
      empty.textContent = t("quotaEmpty");
      container.appendChild(empty);
    }
  });
}

function refreshAll() {
  applyStaticTranslations();
  loadSettings();
  loadUsage();
  loadOfficialQuota();
}

document.getElementById("addSiteBtn").addEventListener("click", addCustomSite);

document.getElementById("globalToggle").addEventListener("change", (e) => {
  chrome.storage.local.set({ rtlEnabled: e.target.checked });
});

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab + "Tab").classList.add("active");
  });
});

document.getElementById("langSwitchBtn").addEventListener("click", () => {
  CURRENT_LANG = CURRENT_LANG === "fa" ? "en" : "fa";
  chrome.storage.local.set({ uiLang: CURRENT_LANG });
  refreshAll();
});

getCurrentLang((lang) => {
  CURRENT_LANG = lang;
  refreshAll();
});
