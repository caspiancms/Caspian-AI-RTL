// تاریخ به‌صورت YYYY-MM-DD (میلادی، برای مرتب‌سازی ساده) ذخیره می‌شود
function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function pruneOldData(usage) {
  // فقط ۹۰ روز اخیر را نگه می‌داریم تا storage بزرگ نشود
  const cutoff = Date.now() - 90 * 24 * 60 * 60 * 1000;
  for (const dateKey of Object.keys(usage)) {
    const t = new Date(dateKey).getTime();
    if (!isNaN(t) && t < cutoff) {
      delete usage[dateKey];
    }
  }
  return usage;
}

// ---------- ثبت پویای اسکریپت محتوا برای سایت‌های دلخواه کاربر ----------
// هر آیتم customSites به‌صورت { key, label, host } ذخیره می‌شود.
// برای هرکدام یک content script با scripting API ثبت می‌کنیم تا بدون نیاز
// به بازنشر افزونه، روی همان دامنه هم راست‌چین و شمارش توکن کار کند.

function scriptIdFor(key) {
  return `custom-ai-site-${key}`;
}

async function registerCustomSite(site) {
  const id = scriptIdFor(site.key);
  const matches = [`*://${site.host}/*`, `*://*.${site.host}/*`];
  try {
    // اگر قبلاً ثبت شده بود، اول حذفش می‌کنیم تا خطای تکراری ندهد
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
    if (existing.length > 0) {
      await chrome.scripting.unregisterContentScripts({ ids: [id] });
    }
  } catch (e) {
    /* اگر وجود نداشت، ادامه می‌دهیم */
  }
  await chrome.scripting.registerContentScripts([
    {
      id,
      matches,
      js: ["content.js"],
      css: ["rtl.css"],
      runAt: "document_idle",
    },
  ]);
}

async function unregisterCustomSite(key) {
  const id = scriptIdFor(key);
  try {
    await chrome.scripting.unregisterContentScripts({ ids: [id] });
  } catch (e) {
    /* اگر از قبل ثبت نبود، مشکلی نیست */
  }
}

async function reRegisterAllCustomSites() {
  const data = await chrome.storage.local.get(["customSites"]);
  const customSites = data.customSites || [];
  for (const site of customSites) {
    try {
      await registerCustomSite(site);
    } catch (e) {
      console.warn("خطا در ثبت اسکریپت برای", site.host, e);
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "AI_USAGE_UPDATE") {
    const { site, tokens } = message;
    chrome.storage.local.get(["usage"], (data) => {
      const usage = data.usage || {};
      const dateKey = todayKey();
      if (!usage[dateKey]) usage[dateKey] = {};
      usage[dateKey][site] = (usage[dateKey][site] || 0) + tokens;
      pruneOldData(usage);
      chrome.storage.local.set({ usage });
    });
    return false;
  }

  if (message && message.type === "OFFICIAL_QUOTA_UPDATE") {
    const { site, quotas } = message;
    chrome.storage.local.get(["officialQuota"], (data) => {
      const officialQuota = data.officialQuota || {};
      officialQuota[site] = { quotas, detectedAt: Date.now() };
      chrome.storage.local.set({ officialQuota });
    });
    return false;
  }

  if (message && message.type === "REGISTER_CUSTOM_SITE") {
    registerCustomSite(message.site)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true; // پاسخ async
  }

  if (message && message.type === "UNREGISTER_CUSTOM_SITE") {
    unregisterCustomSite(message.key)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true; // پاسخ async
  }

  return false;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["rtlEnabled"], (data) => {
    if (data.rtlEnabled === undefined) {
      chrome.storage.local.set({ rtlEnabled: true });
    }
  });
  reRegisterAllCustomSites();
});

chrome.runtime.onStartup.addListener(() => {
  reRegisterAllCustomSites();
});
